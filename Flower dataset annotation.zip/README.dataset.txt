# Image_Classification_MultiLable > 2025-10-18 8:38pm
https://universe.roboflow.com/sivadhanya-s/image_classification_multilable-rts2r

Provided by a Roboflow user
License: CC BY 4.0

